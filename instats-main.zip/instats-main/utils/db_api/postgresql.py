import asyncio
from typing import Union
import logging
import asyncpg
from asyncpg import Connection
from asyncpg.pool import Pool

from data import config


class Database:

    def __init__(self):
        self.pool: Union[Pool, None] = None

    async def create(self):
        self.pool = await asyncpg.create_pool(dsn=config.DSN
            # user=config.DB_USER,
            # password=config.DB_PASS,
            # host=config.DB_HOST,
            # database=config.DB_NAME

        )

    async def execute(self, command: object, *args: object,
                      fetch: bool = False,
                      fetchval: bool = False,
                      fetchrow: bool = False,
                      execute: bool = False
                      ) -> object:
        async with self.pool.acquire() as connection:
            connection: Connection
            async with connection.transaction():
                if fetch:
                    result = await connection.fetch(command, *args)
                elif fetchval:
                    result = await connection.fetchval(command, *args)
                elif fetchrow:
                    result = await connection.fetchrow(command, *args)
                elif execute:
                    result = await connection.execute(command, *args)
            return result

    async def create_table_users(self):
        sql = """
        CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,
        username varchar(255) NULL,
        lang varchar(2) DEFAULT('en'),
        user_id BIGINT NOT NULL UNIQUE,
        phone varchar(20) NULL
        );
        """
        await self.execute(sql, execute=True)

    @staticmethod
    def format_args(sql, parameters: dict):
        sql += " AND ".join([
            f"{item} = ${num}" for num, item in enumerate(parameters.keys(),
                                                          start=1)
        ])
        return sql, tuple(parameters.values())

    async def add_user(self, full_name, username, telegram_id):
        sql = "INSERT INTO users (full_name, username, user_id) VALUES($1, $2, $3) returning *"
        logging.debug(f"request>>>\n{sql}")
        return await self.execute(sql, full_name, username, telegram_id, fetchrow=True)

    async def update_phone(self, phone, user_id):
        sql = "UPDATE users SET phone=$1 WHERE user_id=$2"
        await self.execute(sql, phone, user_id, execute=True)

    async def get_user_id(self, user_id):
        sql = "SELECT user_id FROM basket WHERE user_id = $1"
        return await self.execute(sql, user_id, fetchrow=True)

    async def get_lang(self, user_id):
        return await self.execute(f"select lang from users where user_id = {user_id}", fetchval=True)

    async def update_lang(self, user_id, lang):
        sql = "UPDATE users SET lang=$1 WHERE user_id=$2"
        return await self.execute(sql, lang, user_id, execute=True)

    async def select_all_users(self):
        sql = "SELECT * FROM users"
        return await self.execute(sql, fetch=True)

    async def select_user(self, user_id):
        sql = "SELECT * FROM users WHERE user_id = $1"
        return await self.execute(sql, user_id, fetchrow=True)

    async def count_users(self):
        sql = "SELECT COUNT(*) FROM users"
        return await self.execute(sql, fetchval=True)

    async def select_phone(self, user_id):
        sql = "SELECT phone FROM users WHERE user_id = $1"
        return await self.execute(sql, user_id, fetchval=True)

    async def update_user_username(self, username, telegram_id):
        sql = "UPDATE users SET username=$1 WHERE user_id=$2"
        return await self.execute(sql, username, telegram_id, execute=True)

    async def update_name(self, user_id, new_name):
        sql = "UPDATE users SET full_name=$1 WHERE user_id=$2"
        await self.execute(sql, new_name, user_id, execute=True)

    async def delete_users(self):
        await self.execute("DELETE FROM users WHERE TRUE", execute=True)

    async def drop_users(self):
        await self.execute("DROP TABLE users", execute=True)

    async def delete_basket_item(self, basket_id):
        sql = "DELETE FROM basket WHERE id=$1"
        return await self.execute(sql, basket_id, execute=True)
