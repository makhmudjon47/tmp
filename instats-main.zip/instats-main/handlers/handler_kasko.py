from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ContentTypes
from pprint import pprint
import logging
from keyboards.default.main_menu_keyboard import *
from loader import dp, _, bot, db
from handlers.osago_handlers import osago_confirm
from . import back_handler




async def kasko_car_brend(message: Message, state: FSMContext):
    await message.answer(_("Укажите марку автомобиля"), reply_markup=back_keyboard())
    await state.set_state("kasko_details_brand")
    return



async def kasko_car_brend_without_state(message:Message, state:FSMContext):
    await message.answer(_("Укажите модель автомобиля"), reply_markup=back_keyboard())
    await state.set_state("kasko_details_model")
    return



async def kasko_car(message: Message, state: FSMContext):
    await state.update_data(car_brand=message.text)
    await message.answer(_("Укажите модель автомобиля"), reply_markup=back_keyboard())
    await state.set_state("kasko_details_model")
    return


async def kasko_car_model(message: Message, state: FSMContext):
    await state.update_data(car_model=message.text)
    await message.answer(_("Укажите государственный номер автомобиля"), reply_markup=back_keyboard())
    await state.set_state("kasko_details_number")
    return


async def kasko_car_number(message: Message, state: FSMContext):
    await state.update_data(car_number=message.text)
    await message.answer(_("Укажите номер технического паспорта"), reply_markup=back_keyboard())
    await state.set_state("kasko_details_passport")
    return


async def kasko_car_passport(message: Message, state: FSMContext):
    await state.update_data(car_passport=message.text)
    all_data = await state.get_data()
    car_brand = all_data.get("car_brand")
    car_model = all_data.get("car_model")
    car_number = all_data.get("car_number")
    car_passport = all_data.get("car_passport")
    await message.answer(_("Please confirm your data"))
    all_text = _("Brand: ") + "<code>" + car_brand + "</code>" + '\n'
    all_text += _("Model: ") + "<code>" + car_model + "</code>" + '\n'
    all_text += _("Number: ") + "<code>" + car_number + "</code>" + '\n'
    all_text += _("Passport: ") + "<code>" + car_passport + "</code>" + '\n'
    logging.info(all_text)
    await message.answer(all_text, reply_markup=osago_confirm_keyboard())
    await state.set_state("kasko_details_confirm")
    return


async def kasko_car_confirm(message: Message, state: FSMContext):
    await osago_confirm(message, state, "КАСКО (Добровольное автострахование)")
