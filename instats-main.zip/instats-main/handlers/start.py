from aiogram import types

from aiogram.types import Message, CallbackQuery

from keyboards.inline.lang_keyboard import make_lang, lang_call
from keyboards.default.main_menu_keyboard import main_menu
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
import asyncio
import logging
from loader import bot, dp, _, db


# @dp.message_handler(commands=['start'], state="*")
async def start_message(message: Message, state: FSMContext):
    user = await db.select_user(message.from_user.id)
    if user:
        await message.answer(_("Welcome"), reply_markup=main_menu())
        await state.set_state("main_menu")
        return
    await db.add_user(message.from_user.full_name,
                      message.from_user.username, message.from_user.id)
    await message.answer("Hello please choose language! \nAssalomu alaykum iltimos kerakli tilni tanlang!\n"
                         "Здравствуйте, пожалуйста, выберите нужный язык!", reply_markup=make_lang())


@dp.callback_query_handler(lang_call.filter(), state="*", chat_type="private")
async def lang_inline_callback(call: CallbackQuery, callback_data: dict, state: FSMContext):
    lang = callback_data.get("lang")
    await db.update_lang(call.from_user.id, lang)
    await call.message.edit_text(_("Language changed", lang), reply_markup=make_lang(lang))
    await asyncio.sleep(1)
    await call.message.delete()
    await call.message.answer(_("Welcome", locale=lang), reply_markup=main_menu(lang))
    await state.set_state("main_menu")


async def help_feedback() -> str:
    return _("""📍<b>Manzil</b>:
A. Temur ko'chasi, 1-o'tish joyi, 6-bino,Toshkent shahri, O'zbekiston, 100000

☎️<b>Yagona telefon raqami</b>:
1166

📥<b>Faks</b>:
+998(71) 232 23 07

📩<b>Elektron manzil</b>:
info@gross.uz""")



@dp.message_handler(CommandStart(deep_link="admin"))
async def test(message: types.Message):
    await bot_start_test(message)

@dp.message_handler(state='*')
async def bot_start_test(message: types.Message):
    if "❌" in message.text:
        await message.answer("Отменено", reply_markup=types.ReplyKeyboardRemove())
        return
    await message.answer('nooooooo')
