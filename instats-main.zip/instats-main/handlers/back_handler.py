from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ContentTypes
from pprint import pprint
from keyboards.default.main_menu_keyboard import *
from loader import dp, _, bot, db
from data.config import ADMINS
from handlers.osago_handlers import *
from handlers.handler_kasko import *
from handlers.start import *
from handlers.travel_handlers import *



# @dp.message_handler(state="*")
async def back_hand(message: Message, state: FSMContext):
    curr_state = await state.get_state()
    if message.text in ['◀️Ortga', '◀️Назад', "◀️Back"]:
        if curr_state == "insurence_type":
            await start_message(message, state)
            logging.info(f"User {message.from_user.id} went [back] to main menu")
            return
        elif curr_state == "osago_transport_type" :
            await buy_policy(message, state)
            logging.info(f"User {message.from_user.id} went [back] to insurence type menu")
            return
        elif curr_state == "osago_region":
            await osago_car_type(message, state)
            logging.info(f"User {message.from_user.id} went [back] to osago transport type menu")
            return
        elif curr_state == "osago_period":
            await osago_car_without_update(message, state) #TODO: change func without update datax
            logging.info(f"User {message.from_user.id} went [back] to osago region menu")
            return
        elif curr_state == "osago_car_number":
            await osago_period(message, state)
            logging.info(f"User {message.from_user.id} went [back] to osago period menu")
            return
        elif curr_state == "osago_passport":
            await osago_car_number(message, state)
            logging.info(f"User {message.from_user.id} went [back] to osago car number menu")
            return


        # travel back handlers
        elif curr_state == "travel_country":
            await buy_policy(message, state)
            logging.info(f"User {message.from_user.id} went [back] to osago buy policy menu")
            return
        elif curr_state == "travel_period":
            await travel_insurnace(message, state)
            logging.info(f"User {message.from_user.id} went [back] to travel country menu")
            return
        elif curr_state == "travel_goal":
            await travel_insurance_period(message, state)
            logging.info(f"User {message.from_user.id} went [back] to travel period menu")
            return
        elif curr_state == "travel_covid":
            await travel_insurance_goal(message, state)
            logging.info(f"User {message.from_user.id} went [back] to travel goal menu")
            return
        elif curr_state == "travel_dob":
            await travel_insurance_covid(message, state)
            logging.info(f"User {message.from_user.id} went [back] to travel covid menu")
            return
        # kasko back handlers
        elif curr_state == "kasko_details_brand":
            await buy_policy(message, state)
            logging.info(f"User {message.from_user.id} went [back] to osago buy policy  menu")
            return
        elif curr_state == "kasko_details_model":
            await kasko_car_brend(message, state)
            logging.info(f"User {message.from_user.id} went [back] to kasko details brand menu")
            return
        elif curr_state == "kasko_details_number":
            await kasko_car(message, state)
            logging.info(f"User {message.from_user.id} went [back] to kasko details model menu")
            return
        elif curr_state == "kasko_details_passport":
            await kasko_car_model(message, state)
            logging.info(f"User {message.from_user.id} went [back] to kasko details number menu")
            return

        else:
            await start_message(message, state)
            logging.info(f" state = {curr_state }")
            logging.info(f"User {message.from_user.id} went [back] to main menu")
            return

    else:
        if message.is_command() and message.text == "/lang":

            await lang_message(message, state)
            return
        elif message.text in ["Feedback", "Обратная связь", "Aloqaga chiqish"]:
            await message.answer(await help_feedback())
            return
        elif message.text in ["Europrotocol", "Yevro protokol", "Евро протокол"]:
            await message.answer_document("https://drive.google.com/uc?export=download&id=1EGlhl8DQECwdmrzlzEfoTxogG3o8TKiT")
            return
        # osago handlers
        if curr_state == "insurence_type":
            await osago(message, state)
            logging.info(f"User {message.from_user.id} went to osago menu")
            return
        elif curr_state == "osago_transport_type":
            await osago_car(message, state)
            logging.info(f"User {message.from_user.id} went to osago car menu")
            return
        elif curr_state == "osago_region":
            await osago_region(message, state)
            logging.info(f"User {message.from_user.id} went to osago region menu")
            return
        elif curr_state == "osago_period":
            await osago_period(message, state)
            logging.info(f"User {message.from_user.id} went to osago period menu")
            return
        elif curr_state == "osago_car_number":
            await osago_car_number(message, state)
            logging.info(f"User {message.from_user.id} went to osago car number menu")
            return
        elif curr_state == "osago_passport":
            await osago_passport(message, state)
            logging.info(f"User {message.from_user.id} went to osago confirm menu")
            return
        elif curr_state == "osago_confirm":
            await osago_confirm(message, state, "ОСАГО (Обязательное автострахование)")
            logging.info(f"User {message.from_user.id} went to osago confirm menu")
            return

        # osago renewal handlers
        elif curr_state == 'osago_choice':
            await osago_choice_maker(message, state)
            logging.info(f"User {message.from_user.id} went to choice maker osago ")
            return
        elif curr_state == 'osago_extend':
            await osago_extend_getter(message, state)
            logging.info(f"User {message.from_user.id} went confirm renew osago polic")
            return 

        elif curr_state == 'osago_renew_confirm':
            await osago_confirm(message, state, "Продлить полиc")
            logging.info(f"User {message.from_user.id} confirmed or refused ")

        
        # kasco handlers here
        elif curr_state == "kasko_details_brand":
            await kasko_car(message, state)
            logging.info(f"User {message.from_user.id} went to kasko car brand menu")
            return
        elif curr_state == "kasko_details_model":
            await kasko_car_model(message, state)
            logging.info(f"User {message.from_user.id} went to kasko car model menu")
            return
        elif curr_state == "kasko_details_number":
            await kasko_car_number(message, state)
            logging.info(f"User {message.from_user.id} went to kasko car number menu")
            return
        elif curr_state == "kasko_details_passport":
            await kasko_car_passport(message, state)
            logging.info(f"User {message.from_user.id} went to kasko passport menu")
            return
        elif curr_state == "kasko_details_confirm":
            await kasko_car_confirm(message, state)
            logging.info(f"User {message.from_user.id} went to kasko confirm menu")
            return
        # travel handlers here
        elif curr_state == "travel_country":
            await travel_country(message, state)
            logging.info(f"User {message.from_user.id} went to travel country menu")
            return
        elif curr_state == "travel_period":
            await travel_period(message, state)
            logging.info(f"User {message.from_user.id} went to travel period menu")
            return
        elif curr_state == "travel_goal":
            await travel_goal(message, state)
            logging.info(f"User {message.from_user.id} went to travel goal menu")
        elif curr_state == "travel_covid":
            await travel_covid(message, state)
            logging.info(f"User {message.from_user.id} went to travel covid menu")
        elif curr_state == "travel_dob":
            await travel_dob(message, state)
            logging.info(f"User {message.from_user.id} went to travel dob menu")
        elif curr_state == "travel_confirm":
            await travel_confirm(message, state)
            logging.info(f"User {message.from_user.id} went to travel confirm menu")
        elif curr_state == "main_menu":
            await buy_policy(message, state)
        return





@dp.message_handler(commands=['lang'], state="main_menu")
@dp.message_handler(commands=['lang'], state="*")
async def lang_message(message: Message, state: FSMContext):
    await message.answer(_("Please choose language! "), reply_markup=make_lang())
