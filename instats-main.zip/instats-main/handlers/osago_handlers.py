from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ContentTypes
from pprint import pprint
from keyboards.default.main_menu_keyboard import *
from loader import dp, _, bot, db
from data.config import ADMINS
from . import back_handler


async def buy_policy(message: Message, state: FSMContext):
    contact = await db.select_phone(message.from_user.id)
    if contact:
        await message.answer(_("Choose a policy type:"), reply_markup=insurence_key())
        await state.set_state("insurence_type")
        return
    await message.answer(_("Please share your phone number:"), reply_markup=get_contact())
    await state.set_state("get_phone_number")


@dp.message_handler(content_types=ContentTypes.CONTACT | ContentTypes.TEXT, state="get_phone_number")
async def get_phone_number(message: Message, state: FSMContext):
    await db.update_phone(message.contact.phone_number, message.from_user.id)
    await buy_policy(message, state)
    return


async def osago(message: Message, state: FSMContext):
    await state.update_data(insurence_type=message.text)

    if message.text in ["OSAGO (Compulsory car insurance)", "ОСАГО (Обязательное автострахование)",
                        "OSAGO (Majburiy avtosug'urta)"]:
        await state.update_data(insurance_type=message.text)
        await message.answer(_('Please, choose these options:'), reply_markup=osago_choice())
        await state.set_state('osago_choice')  # TODO
        return
    elif message.text in ["KASCO (Voluntary car insurance)", "КАСКО (Добровольное автострахование)",
                          "KASKO (Ixtiyoriy avtosug'urta)"]:
        await message.answer(_("Укажите марку автомобиля"), reply_markup=back_keyboard())
        await state.set_state("kasko_details_brand")
        return
    else:
        await message.answer(_("Where do you want to go?"), reply_markup=back_keyboard())
        await state.set_state("travel_country")
        return

async def osago_choice_maker(message:Message, state:FSMContext):
    if message.text in {"Extend current policy", "Продлить текущую полис", "Joriy polisni yangilash"}:
        await osago_renew(message, state)
    else:
        await osago_car_transport_type(message, state)
    return

async def osago_renew(message: Message, state: FSMContext):
    await message.answer(_("Please, enter your polic number \nExample: GIU 00000000"), reply_markup=back_keyboard())
    await state.set_state("osago_extend")  # TODO


async def osago_extend_getter(message: Message, state: FSMContext):
    await state.update_data(polic_num=message.text)  # TODO
    await message.answer(_("Please, confirm your data:"))
    all_data = await state.get_data()
    await message.answer(_("Polic number : %s") % message.text, reply_markup=osago_confirm_keyboard())
    await state.set_state("osago_renew_confirm")


async def osago_car_transport_type(message: Message, state: FSMContext):
    await message.answer(_("Choose a transport type:"), reply_markup=osago_transport())
    await state.set_state("osago_transport_type")


async def osago_car_type(message: Message, state: FSMContext):
    await message.answer(_("Choose a transport type:"), reply_markup=osago_transport())
    await state.set_state("osago_transport_type")
    return


async def osago_car(message: Message, state: FSMContext):
    await state.update_data(transport_type=message.text)
    await message.answer(_("Choose a region:"), reply_markup=osago_regions_others())
    await state.set_state("osago_region")
    return


async def osago_car_without_update(message: Message, state: FSMContext):
    await message.answer(_("Choose a region:"), reply_markup=osago_regions_others())
    await state.set_state("osago_region")
    return


async def osago_region(message: Message, state: FSMContext):
    await state.update_data(region=message.text)
    await message.answer(_("Choose a period:"), reply_markup=period_osago())
    await state.set_state("osago_period")
    return


async def osago_period(message: Message, state: FSMContext):
    await state.update_data(period=message.text)
    await message.answer(_("Please provide your vehicle number:\n In format 01A123AA"),
                         reply_markup=ReplyKeyboardRemove())
    await state.set_state("osago_car_number")
    return


async def osago_car_number(message: Message, state: FSMContext):
    if message.text[0:2].isdigit() and message.text[2:3].isalpha() and message.text[3:6].isdigit() and message.text[
                                                                                                       6:8].isalpha():
        await state.update_data(car_number=message.text)
        await message.answer(_("Please provide your technical passport:"), reply_markup=ReplyKeyboardRemove())
        await state.set_state("osago_passport")
        return
    await message.answer(_("Please provide your vehicle number:/n In format 01A123AA"),
                         reply_markup=ReplyKeyboardRemove())
    return


async def osago_passport(message: Message, state: FSMContext):
    await state.update_data(passport=message.text)
    all_data = await state.get_data()
    pprint(all_data)
    car_number = _("Car Number: ")
    passport = _("Passport: ")
    insurence_type = _("Insurence Type: ")
    transport_type = _("Transport Type: ")
    region = _("Region: ")
    period = _("Period: ")

    all_text = insurence_type + "<code>" + all_data["insurence_type"] + "</code>" + '\n'
    all_text += transport_type + "<code>" + all_data["transport_type"] + "</code>" + '\n'
    all_text += region + "<code>" + all_data["region"] + "</code>" + '\n'
    all_text += period + "<code>" + all_data["period"] + "</code>" + '\n'
    all_text += car_number + "<code>" + all_data["car_number"] + "</code>" + '\n'
    all_text += passport + "<code>" + all_data["passport"] + "</code>" + '\n'

    await message.answer(_("Please confirm your data:\n "))
    await message.answer(all_text, reply_markup=osago_confirm_keyboard())
    await state.set_state("osago_confirm")


async def osago_confirm(message: Message, state: FSMContext, insurance_type=None):
    if message.text in ["Yes", "Да", 'Ha']:
        await message.answer(_("Thank you for your purchase!\nSoon our operators will reach out you"),
                             reply_markup=main_menu())
        for admin in ADMINS:
            user_data = f"User ID in db: {message.from_user.id}\n"
            user_data += f"User Name: {message.from_user.full_name}\n"
            user_data += f"User Phone: +{await db.select_phone(message.from_user.id)}\n"
            user_data += f"User Language: {await db.get_lang(message.from_user.id)}\n"
            user_data += f"User Username: @{message.from_user.username}\n"
            user_data += f"User Insurance Type: {insurance_type}\n"
            sent_message = await bot.send_message(admin, user_data)
            await bot.copy_message(admin, message.from_user.id, message.message_id - 1,
                                   reply_to_message_id=sent_message.message_id)

        await state.set_state("main_menu")
        return
    await message.answer(_("Our services: "), reply_markup=main_menu())
    await state.set_state("main_menu")
    return
