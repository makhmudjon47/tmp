from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.types import ContentTypes
from pprint import pprint
from keyboards.default.main_menu_keyboard import *
from loader import dp, _, bot, db
from data.config import ADMINS
from handlers.osago_handlers import osago_confirm


async def travel_insurnace(message: Message, state: FSMContext):
    await message.answer(_("Where do you want to go?"), reply_markup=back_keyboard())
    await state.set_state("travel_country")
    return


async def travel_insurance_period(message:Message, state:FSMContext):
    await message.answer(_("Please enter period of travel"), reply_markup=back_keyboard())
    await state.set_state("travel_period")
    return
async def travel_insurance_goal(message: Message, state: FSMContext):
    await message.answer(_("What is goal of this travel?"), reply_markup=travel_insurance_keyboard())
    await state.set_state("travel_goal")

async def travel_insurance_covid(message: Message, state: FSMContext):
    await message.answer(_("Do you what additional insurance? \n Insurance of COVID-19")
                         , reply_markup=osago_confirm_keyboard())
    await state.set_state("travel_covid")
    return



async def travel_country(message: Message, state: FSMContext):
    await state.update_data(country=message.text)
    await message.answer(_("Please enter period of travel"), reply_markup=back_keyboard())
    await state.set_state("travel_period")


async def travel_period(message: Message, state: FSMContext):
    await state.update_data(period=message.text)
    await message.answer(_("What is goal of this travel?"), reply_markup=travel_insurance_keyboard())
    await state.set_state("travel_goal")


async def travel_goal(message: Message, state: FSMContext):
    await state.update_data(goal=message.text)
    await message.answer(_("Do you what additional insurance? \n Insurance of COVID-19")
                         , reply_markup=osago_confirm_keyboard())
    await state.set_state("travel_covid")


async def travel_covid(message: Message, state: FSMContext):
    if message.text in ["Yes", "Да", "Ha"]:
        await state.update_data(covid=True)
    else:
        await state.update_data(covid=False)

    await message.answer(_("Please enter your date of birth in format dd.mm.yyyy:<b> 01.01.2000 </b>"),
                         reply_markup=back_keyboard())
    await state.set_state("travel_dob")


async def travel_dob(message: Message, state: FSMContext):
    await state.update_data(dob=message.text)
    all_data = await state.get_data()
    country = all_data.get("country")
    period = all_data.get("period")
    goal = all_data.get("goal")
    covid = all_data.get("covid")
    dob = all_data.get("dob")
    txt = _("Please confirm your data: ")
    await message.answer(txt)
    txt = ""
    txt += _("Country: ") + country + "\n"
    txt += _("Period: ") + period + "\n"
    txt += _("Goal: ") + goal + "\n"
    txt += "Covid: ❌\n" if not covid else "Covid:  ✅\n"
    txt += _("Date of birth: ") + dob + "\n"
    await message.answer(txt, reply_markup=osago_confirm_keyboard())
    await state.set_state("travel_confirm")


async def travel_confirm(message: Message, state: FSMContext):
    await osago_confirm(message, state, "Страхование путешествующих")
