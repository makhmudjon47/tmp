# Gross Bot 
## Necessary resources
I am assuming that you are going to deploy this bot to AWS EC2 or other Ubuntu machine 

* postgresql 14
* python3.8 
* supervisorctl


it's hirerchy of bot:
```bash
.
├── bot
│   ├── app.py
│   ├── data
│   │   ├── config.py
│   │   └── __init__.py
│   ├── handlers
│   │   ├── back_handler.py
│   │   ├── handler_kasko.py
│   │   ├── __init__.py
│   │   ├── osago_handlers.py
│   │   ├── start.py
│   │   └── travel_handlers.py
│   ├── keyboards
│   │   ├── default
│   │   │   ├── __init__.py
│   │   │   └── main_menu_keyboard.py
│   │   ├── __init__.py
│   │   └── inline
│   │       ├── __init__.py
│   │       └── lang_keyboard.py
│   ├── lang_instructions.txt
│   ├── loader.py
│   ├── locales
│   │   ├── en
│   │   │   └── LC_MESSAGES
│   │   │       ├── grossbot.mo
│   │   │       └── grossbot.po
│   │   ├── grossbot.pot
│   │   ├── ru
│   │   │   └── LC_MESSAGES
│   │   │       ├── grossbot.mo
│   │   │       └── grossbot.po
│   │   └── uz
│   │       └── LC_MESSAGES
│   │           ├── grossbot.mo
│   │           └── grossbot.po
│   ├── middlewares
│   │   ├── __init__.py
│   │   ├── lang_middleware.py
│   │   └── throttling.py
│   ├── Procfile
│   ├── README.md
│   ├── requirements.txt
│   └── utils
│       ├── bot_commands.py
│       ├── db_api
│       │   ├── __init__.py
│       │   └── postgresql.py
│       ├── __init__.py
│       ├── misc
│       │   ├── logging.py
│       │   └── throttling.py
│       └── notify_admins.py
└── README.md
```




for postgresql setup refer to [link](https://www.digitalocean.com/community/tutorials/how-to-set-up-django-with-postgres-nginx-and-gunicorn-on-ubuntu-20-04)


first place your all envirenment variables into `.env`

after successfully putting all env vars to .env file 
install needed packages to python 
```bash
pip3 install -r /bot/requirements.txt
```

start the bot 
```bash
python3 app.py

```