from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from loader import _


def back_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def main_menu(lang=None):
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text=_("Купить полис", locale=lang)),
                KeyboardButton(text=_("Обратная связь", locale=lang)),
                KeyboardButton(text=_("Евро протокол", locale=lang)),
            ],
        ],
        resize_keyboard=True,
    )


def insurence_key():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("ОСАГО (Обязательное автострахование)"))],
            [KeyboardButton(text=_("КАСКО (Добровольное автострахование)"))],
            [KeyboardButton(text=_("Страхование путешествующих"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
    )

def osago_choice():
    return ReplyKeyboardMarkup(
        resize_keyboard=True,
        one_time_keyboard=True,
        keyboard=[
            [KeyboardButton(text=_("Extend current policy"))],
            [KeyboardButton(text=_("Buy new policy"))],
            [KeyboardButton(text=_('Back'))]
        ]
    )







def osago_transport():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Легковой автомобиль"))],
            [KeyboardButton(text=_("Грузовой автомобиль"))],
            [KeyboardButton(text=_("Автобус"))],
            [KeyboardButton(text=_("Мотоцикл"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True

    )


def osago_regions():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Ташкент"))],
            [KeyboardButton(text=_("Другие регионы"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
    )


def osago_regions_others():
    regions_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True, row_width=2,
                                           keyboard=[
[KeyboardButton(_("Tashkent")), KeyboardButton(_("Other regions"))],
                                               [KeyboardButton(text=_("Back"))]
                                           ])
    return regions_keyboard


def period_osago():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("1 год"))],
            [KeyboardButton(text=_("6 месяцев"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def back():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def travel_aim_key():
    regions_keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)

    vars = [
        [KeyboardButton(_("Путешествие"))],
        [KeyboardButton(_("Обучение за рубежом"))],
        [KeyboardButton(_("Спорт/активный отдых"))],
        [KeyboardButton(_("Работа"))],
        [KeyboardButton(_("Back"))]
    ]

    regions_keyboard.row(*vars)
    return regions_keyboard


def get_contact():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Share your phone number"), request_contact=True)],
            [KeyboardButton(text=_("Back"))]
        ],
        resize_keyboard=True,
    )


def osago_confirm_keyboard():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Да"))],
            [KeyboardButton(text=_("Нет"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def kasko_details_keyboard():
    """Укажите марку автомобиля
Укажите модель автомобиля
Укажите государственный номер
Укажите номер технического паспорта
make default keyborad for kasko"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Укажите марку автомобиля"))],
            [KeyboardButton(text=_("Укажите модель автомобиля"))],
            [KeyboardButton(text=_("Укажите государственный номер"))],
            [KeyboardButton(text=_("Укажите номер технического паспорта"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def travel_insurance_keyboard():
    """Путешествие
Обучение за рубежом
Спорт/активный отдых
Работа
make default keyborad for kasko"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=_("Путешествие"))],
            [KeyboardButton(text=_("Обучение за рубежом"))],
            [KeyboardButton(text=_("Спорт/активный отдых"))],
            [KeyboardButton(text=_("Работа"))],
            [KeyboardButton(text=_("Back"))],
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
