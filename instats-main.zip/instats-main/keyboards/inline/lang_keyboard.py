from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.callback_data import CallbackData

lang_call = CallbackData("language", "lang")


def lang_callback(lang):
    return lang_call.new(lang=lang)


from loader import _


def make_lang(current=None):
    if current == 'en':
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=("🌍O'zbekcha"), callback_data=lang_callback(lang="uz"))],
                [InlineKeyboardButton(text=("🌍Русский"), callback_data=lang_callback(lang="ru"))],
                [InlineKeyboardButton(text=("🔘 🌍English"), callback_data=lang_callback(lang="en"))],
            ]
        )
    elif current == 'ru':
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=("🌍O'zbekcha"), callback_data=lang_callback(lang="uz"))],
                [InlineKeyboardButton(text=("🔘 🌍Русский"), callback_data=lang_callback(lang="ru"))],
                [InlineKeyboardButton(text=("🌍English"), callback_data=lang_callback(lang="en"))],
            ]
        )

    elif current == 'uz':
        return InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text=("🔘🌍O'zbekcha"), callback_data=lang_callback(lang="uz"))],
                [InlineKeyboardButton(text=("🌍Русский"), callback_data=lang_callback(lang="ru"))],
                [InlineKeyboardButton(text=("🌍English"), callback_data=lang_callback(lang="en"))],
            ]
        )

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=("🌍O'zbekcha"), callback_data=lang_callback(lang="uz"))],
            [InlineKeyboardButton(text=("🌍Русский"), callback_data=lang_callback(lang="ru"))],
            [InlineKeyboardButton(text=("🌍English"), callback_data=lang_callback(lang="en"))],
        ]
    )
